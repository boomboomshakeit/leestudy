package realtest;

import java.util.Scanner;

public class Test2 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		
		
		char inputChar = 0;

        while (inputChar != 'q' && inputChar != 'Q') {
        	System.out.print("A(a).입력 | Q(q).종료 ");
            inputChar = sc.next().charAt(0);
            if ((inputChar >= 'a' && inputChar <= 'z') || (inputChar >= 'A' && inputChar <= 'Z')) {
                System.out.println("영어입력(띄어쓰기 없이) " + inputChar);
            } else if(inputChar != 'q' && inputChar != 'Q') {
            	System.out.println();
            	
            } else {
            	System.out.println("잘못된 입력 값입니다.");
            }
        }
        System.out.println("프로그램 종료");

        sc.close();
	}

}
