package realtest;

public class Test3 {

	public static void main(String[] args) {
		
		char c = 'a';
		do {
			System.out.println(c);
			c++;
		}while(c <= 'z');
	}

}
